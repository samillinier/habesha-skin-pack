=======
Credits
=======

Development Lead
----------------

* George Pchelkin @gpchelkin <george@pchelk.in>

Contributors
------------

* Leonid Runyshkin @leovp <runyshkin@gmail.com>
* Vadim Larionov @vadimlarionov <larionov.vadim@my.com>
