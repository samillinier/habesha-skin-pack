=====
Usage
=====

To use Music Downloader Telegram Bot in a project::

    import scdlbot
