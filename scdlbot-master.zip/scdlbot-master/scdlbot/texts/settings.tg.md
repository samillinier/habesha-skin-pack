Select working mode for messages *without command*.
Sane defaults are *Download* for *PM* and *Ask* for groups.
Toggle *Captions* off: send audios *without source captions* and *not as replies*.
